To execute
Requirements
The program andd the test needs an stable internet conection
-Python3
In the command line
At ./Tarea01
-> python3 python/main.py files/Angel\ Christian\ Pimentel\ Noriega\ -\ dataset.csv 

For the tests
At ./Tarea01
-> python3 -m unittest python/city_test.py


The .tex file and the pdf is in the ./files/ subdirectory

Thanks
